function params = paper_params()
%PAPER_PARAMS Centralized parameters for the RIS-assisted MIMO-FMCW study.
%   This file is an initialization placeholder. Later implementation rounds
%   should keep paper-derived values and documented reproduction assumptions
%   here instead of scattering constants across scripts.

params.paper.title = "RIS辅助MIMO-FMCW雷达的非视距目标参数估计方法";
params.paper.authors = "王纪萱, 田团伟, 邓浩, 马锐";

params.array.Nt = 4;
params.array.Nb = 4;
params.array.Nr_default = 16;

params.radar.c = 3e8;
params.radar.fc = 77e9;
params.radar.bandwidth = 500e6;
params.radar.chirpTime = 50e-6;
params.radar.sampleRate = 2e6;
params.radar.numChirps = 256;
params.radar.rcs = 1;

params.power.txPower_dBm = 10;
params.power.noisePower_dBm = 10;

params.channel.ricianK_dB = 10;
params.channel.pathLossExponent = 2;

params.optim.maxIter = 1000;
params.optim.tolerances = [1e-2, 1e-3, 1e-4];
params.optim.risReflectionAmplitude = 1;

params.targets.range_m = [25, 20, 10, 5];
params.targets.velocity_mps = [-1, 1, -1, 1];

params.repro.rngSeed = 20251009;
params.repro.status = "placeholder_only_no_algorithm_implemented";
end
