# Project Architecture

## 项目定位

本项目不是单脚本复现，而是面向长期调试和扩展的 MATLAB 科研复现工程。目标是逐步复现论文《RIS辅助MIMO-FMCW雷达的非视距目标参数估计方法》中的 RIS 辅助 MIMO-FMCW 雷达非视距目标参数估计方法和仿真实验。

## 目录结构

```text
RIS_MIMO_FMCW_Reproduction/
├─ main/
├─ config/
├─ functions/
├─ docs/
├─ outputs/
│  ├─ figures/
│  ├─ data/
│  └─ logs/
└─ README.md
```

## 目录职责

`main/` 存放可直接运行的主脚本。每个主脚本对应一个明确实验或图表复现任务，不能把多个无关功能混写到同一个脚本中。

`config/` 集中保存论文参数和仿真参数。后续所有主脚本和函数应优先从 `config/paper_params.m` 读取参数，避免在多个脚本中重复硬编码。

`functions/` 存放可复用 MATLAB 函数。每个函数只负责一个明确功能，例如信道生成、ZF 预编码、RIS 相移优化、SNR 计算、FMCW 回波生成、距离-多普勒处理和绘图风格管理。

`docs/` 是项目管理核心目录。后续每轮代码修改、公式理解、debug、假设调整和实验结果都必须记录到对应文档。

`outputs/figures/` 保存复现图表，例如 `.png`、`.fig`、`.pdf`。

`outputs/data/` 保存中间数据，例如 `.mat` 文件、SNR 曲线数据、距离-多普勒谱矩阵。

`outputs/logs/` 保存脚本运行日志和必要的文本输出。

## 主脚本规划

- `main_reproduce_all.m`：一键运行全部复现实验。后期在各子实验稳定后再完善。
- `main_fig3_snr_vs_Nris.m`：复现图3，比较 ADMM 与 CD 算法的 SNR 随 RIS 反射单元数量变化曲线。
- `main_fig4_snr_vs_power.m`：复现图4，比较不同 RIS 反射单元数量下 ADMM 与 CD 算法的 SNR 随发射功率变化曲线。
- `main_fig5_range_time_3d.m`：复现图5，多目标距离-时间三维幅度谱。
- `main_fig6_range_doppler_maps.m`：复现图6，不同 RIS 反射单元数量下 ADMM 和 CD 算法的距离-多普勒图。

## 函数规划

- `generate_channels.m`：生成 RIS 辅助雷达系统中的 `H_sr` 和 `H_rd` 信道矩阵。
- `design_precoder_zf.m`：根据等效信道设计迫零预编码矩阵 `B`，并进行功率归一化。
- `optimize_ris_admm.m`：根据论文中的 ADMM 更新公式优化 RIS 相移向量 `v` 或相移矩阵 `Phi`。
- `optimize_ris_cd.m`：实现 CD 坐标下降算法，作为 ADMM 的对比基线。
- `compute_snr.m`：根据等效信道、预编码矩阵和噪声功率计算 SNR。
- `generate_fmcw_echo.m`：生成多目标 FMCW 差拍信号，用于距离和速度估计。
- `range_doppler_fft.m`：对 FMCW 回波进行距离 FFT 和多普勒 FFT，生成距离-多普勒谱。
- `plot_utils.m`：统一图表格式，例如坐标轴、字体、图例和保存路径。

## 文档更新规范

1. 每次新增、删除或修改文件后，必须更新 `project_architecture.md`。
2. 每次修改核心公式或变量定义后，必须更新 `paper_formula_notes.md`。
3. 每次新增合理假设后，必须更新 `reproduction_assumptions.md`。
4. 每次运行实验后，必须更新 `experiment_log.md`。
5. 每次遇到错误并修复后，必须更新 `debug_log.md`。
6. 每次完成一个阶段任务后，必须更新 `todo.md`。
7. 不允许在没有说明的情况下大范围重构项目。
8. 不允许把多个功能混写在一个 `main` 脚本里。
9. 不允许为了贴合论文图表而硬编码实验结果。
10. 如果论文细节不足，必须明确标注为“合理复现假设”，不能说成“论文原文如此”。

## 当前阶段

第一轮仅完成工程骨架和文档初版。核心算法、FMCW 回波生成和图3-图6复现均未实现。
