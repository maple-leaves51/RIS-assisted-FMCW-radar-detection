# TODO

## 已完成

- [x] 阅读论文 PDF 并提取第一轮复现所需的核心信息。
- [x] 创建 MATLAB 项目目录结构。
- [x] 创建 `main/`、`config/`、`functions/`、`docs/`、`outputs/`。
- [x] 创建项目管理文档初版。
- [x] 创建 MATLAB 占位脚本和函数。

## 进行中

- [ ] 继续核对论文公式与 MATLAB 矩阵维度。

## 待完成

- [ ] 完善 `paper_params.m` 的参数字段和单位换算。
- [ ] 实现并验证 `generate_channels.m`。
- [ ] 实现并验证 `compute_snr.m`。
- [ ] 实现并验证 `design_precoder_zf.m`。
- [ ] 推导并实现 `optimize_ris_admm.m`。
- [ ] 明确 CD 算法细节并实现 `optimize_ris_cd.m`。
- [ ] 复现图3的 SNR vs RIS 单元数量曲线。
- [ ] 复现图4的 SNR vs 发射功率曲线。
- [ ] 实现 FMCW 多目标回波生成。
- [ ] 实现距离-多普勒 FFT。
- [ ] 复现图5多目标距离-时间三维幅度谱。
- [ ] 复现图6不同 RIS 单元数量下的距离-多普勒图。

## 需要人工确认

- [ ] 图3横轴 `N_r` 取值范围。
- [ ] 图4发射功率扫描范围。
- [ ] 是否严格采用三角扫频上下拍频，还是使用标准 chirp 序列 2D FFT 生成距离-多普勒谱。
- [ ] CD 算法是否需要严格复现引用文献[38]的 accelerated coordinate descent。
- [ ] 是否需要复现论文图中的绝对数值，还是先以趋势一致为阶段目标。
