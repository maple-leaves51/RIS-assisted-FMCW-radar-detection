function [snrLinear, snrDb] = compute_snr(Heff, B, noisePower)
%COMPUTE_SNR Compute SNR from effective channel, precoder, and noise power.
%   Planned formula follows the paper's objective:
%   ||Heff * B||_F^2 / sigma^2, with explicit linear/dB unit handling.

arguments
    Heff
    B
    noisePower
end

unusedInputs = {Heff, B, noisePower}; %#ok<NASGU>
snrLinear = []; %#ok<NASGU>
snrDb = []; %#ok<NASGU>

error("RIS_MIMO_FMCW:NotImplemented", ...
    "compute_snr is a placeholder. Implement after unit conventions are fixed.");
end
