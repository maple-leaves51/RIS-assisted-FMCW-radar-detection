function [B, meta] = design_precoder_zf(Heff, params)
%DESIGN_PRECODER_ZF Design and normalize the ZF precoder.
%   Planned behavior: compute a Moore-Penrose inverse based precoder and
%   normalize it so that ||B||_F^2 <= P.

arguments
    Heff
    params struct
end

unusedInputs = {Heff, params}; %#ok<NASGU>
B = []; %#ok<NASGU>
meta = struct(); %#ok<NASGU>

error("RIS_MIMO_FMCW:NotImplemented", ...
    "design_precoder_zf is a placeholder. Implement after Heff convention is fixed.");
end
