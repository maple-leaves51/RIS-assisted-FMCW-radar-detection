function [Hsr, Hrd, meta] = generate_channels(params)
%GENERATE_CHANNELS Generate RIS-assisted radar channel matrices.
%   Placeholder for the source-to-RIS channel Hsr and RIS-to-target/effective
%   return channel Hrd. Later rounds must document the exact Rician model,
%   path loss, geometry, and matrix dimensions in docs/.

arguments
    params struct
end

unusedInputs = {params}; %#ok<NASGU>
Hsr = []; %#ok<NASGU>
Hrd = []; %#ok<NASGU>
meta = struct(); %#ok<NASGU>

error("RIS_MIMO_FMCW:NotImplemented", ...
    "generate_channels is a placeholder. Implement after dimension audit.");
end
